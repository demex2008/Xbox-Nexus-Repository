#!/usr/bin/pyhton
# -*- coding: utf-8 -*-
import os,sys,urllib,json,re
import xbmc,xbmcplugin,xbmcaddon,xbmcgui,xbmcvfs,resolveurl
from urllib.parse import urlparse

__plugin_handle__ = int(sys.argv[1])
__base_url__ = 'https://kinofox.su'

def __fix_encoding__(path):
	if sys.platform.startswith('win'):return path
	else:return path # .encode('ISO-8859-1')

__addon__ =  xbmcaddon.Addon()
__addon_id__ = __addon__.getAddonInfo('id')
__addon_version__ = __addon__.getAddonInfo('version')
__addon_path__ = __fix_encoding__(__addon__.getAddonInfo('path'))
__addon_icon__ = __fix_encoding__(__addon__.getAddonInfo('icon'))
__addon_fanart__ = __fix_encoding__(__addon__.getAddonInfo('fanart'))

sys.path.append(os.path.join(__addon_path__,'resources','lib'))
import requests,cfscrape

def __get_color_text__(color,text):
	return '[COLOR '+color+']'+text+'[/COLOR]'

def __dialog_imput_alphanum__(heading='',defaultt='',autoclose=0):
	return urllib.parse.quote_plus(xbmcgui.Dialog().input(heading=heading,defaultt=defaultt,type=xbmcgui.INPUT_ALPHANUM,option=xbmcgui.INPUT_ALPHANUM,autoclose=autoclose))

def __get_domain__(url):
    return urlparse(url).netloc

def __get_url_specific_security_headers__(url): #nur py3#

	if url:
	
		if '?' in url:url = url.split('?')[0]

		origin_url = urlparse(url).scheme + '://' + urlparse(url).netloc
		
		return {
			'Origin':origin_url,
			'Referer':url,
			'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36'} # https://deviceatlas.com/blog/list-of-user-agent-strings #
	else:return {}

def __get_cfscrape_sess__(url='',stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict={}):
	sess = requests.Session()
	cfs = cfscrape.create_scraper(sess=sess,delay=delay)
	return cfs.get(url,stream=stream,allow_redirects=allow_redirects,verify=verify,timeout=timeout,headers=headers_dict)


def __post_cfscrape_sess__(url='',data={},stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict={}):
	sess = requests.Session()
	cfs = cfscrape.create_scraper(sess=sess,delay=delay)
	return cfs.post(url,data=data,stream=stream,allow_redirects=allow_redirects,verify=verify,timeout=timeout,headers=headers_dict)

def __regex_search__(regex,content):
	return re.compile(regex,re.DOTALL).search(content)


def __regex_findall__(regex,content):
	return re.compile(regex,re.DOTALL).findall(content)


def __add_item__(url='',title='',image='',fanart='',info_labels_update={},params_update={},add_contextmenu =[],imode='',is_folder=True,is_playable=False):

	iparams = {'url':url,'title':title,'image':image,'fanart':fanart,'imode':imode}
	cparams = {'url':url,'title':title,'image':image,'fanart':fanart}
	iparams.update(params_update)
	cparams.update(params_update)

	info_labels = {'Title':title}
	info_labels.update(info_labels_update)

	listitem = xbmcgui.ListItem(label=title,path=url)
	listitem.setInfo(type='video',infoLabels=info_labels)
	listitem.setArt({'thumb':image,'poster':image,'banner':image,'fanart':fanart})

	if (is_folder == True and is_playable== False):
		url = sys.argv[0] + '?' + urllib.parse.quote_plus(json.dumps(iparams))
		listitem.setProperty('IsPlayable','false')

	elif (is_folder == False and is_playable == False):
		url = sys.argv[0] + '?' + urllib.parse.quote_plus(json.dumps(iparams))
		listitem.setProperty('IsPlayable','true')

	elif (is_folder == False and is_playable == True):
		listitem.setProperty('IsPlayable','true')

	com = []
	for title,cmode in add_contextmenu:
		if title and cmode:
			cparams.update({'cmode':cmode})
			com.append((title,'XBMC.RunPlugin('+ sys.argv[0] + '?' + urllib.parse.quote_plus(json.dumps(cparams)) +')'))
	if com:listitem.addContextMenuItems(items=com,replaceItems=True)

	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=is_folder)


def __get_params__():
	argv = urllib.parse.unquote_plus(sys.argv[2][1:])
	if argv.startswith('{') and argv.endswith('}'):return json.loads(argv)
	else:return None
__params__ = __get_params__()

  
def __end_of_directory__():
	xbmcplugin.endOfDirectory(handle=__plugin_handle__,succeeded=True,updateListing=False,cacheToDisc=True)

def __get_entries_and_next_page__(url='',mode='get'):
    if mode =='get':req = __get_cfscrape_sess__(url=url,stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict=__get_url_specific_security_headers__(url))
    elif mode =='post':req = __post_cfscrape_sess__(url=url,data={},stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict=__get_url_specific_security_headers__(url))

    for  url,title,img in __regex_findall__('short clearfix.*?href="([^"]+).*?title">([^<]+).*? src="([^"]+)',req.text): #<\/article><article class="short clearfix" id="short">[n\s\S]*?<a href="(.+?)"><div class="sh-title">([^>]*?)<\/div>[n\s\S]*?src="(.+?)"#
        __add_item__(url=url,title=title,image=img,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='list_hosters',is_folder=True,is_playable=False)
	
    match = __regex_search__('class="pnext">[^>]*<a[^>]href="([^"]+)">',req.text)
    if match:
        __add_item__(url=match.group(1),title=__get_color_text__('lime','Next >>'),image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='next',is_folder=True,is_playable=False)
	
    __end_of_directory__()


def __get_resolved_url__(url):
	try:
		source = resolveurl.HostedMediaFile(url=url)
		if source.valid_url():return source.resolve()
	except Exception as exc:xbmcgui.Dialog().notification('URL RESOLVER',str(exc),xbmcgui.NOTIFICATION_ERROR,2000,True);sys.exit(0)

def __set_resolved_url__(url=''):### is_folder = False and is_playable = False ###
	listitem = xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(handle=__plugin_handle__,succeeded=True,listitem=listitem)


if __params__ is None:
    __add_item__(url=__base_url__,title='Filme',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='filme',is_folder=True,is_playable=False)
    __add_item__(url=__base_url__,title='Genre',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={'dropdown_list':'Genre'},add_contextmenu =[['','']],imode='get_dropdown_list',is_folder=True,is_playable=False)
    __add_item__(url=__base_url__,title='Release Jahre',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={'Release':'Release'},add_contextmenu =[['','']],imode='Release',is_folder=True,is_playable=False)
    __add_item__(url='',title='Suche',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='suche',is_folder=True,is_playable=False)
    __end_of_directory__()


elif __params__.get('imode') in ['filme','next']:
	__get_entries_and_next_page__(__params__.get('url'))


elif __params__.get('imode') == 'get_dropdown_list':
	
    dropdown_list = __params__.get('dropdown_list')
    url = __params__.get('url')
	
    req = __get_cfscrape_sess__(url=url,stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict=__get_url_specific_security_headers__(url))
	
    match = __regex_search__('">Genre.*?</ul>',req.text)
    if match:
        for url,title in __regex_findall__('href="([^"]+)">([^<]+)',match.group(0)):
            __add_item__(url=__base_url__+url,title=title,image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='get_dropdown_select_url',is_folder=True,is_playable=False)
    __end_of_directory__()

elif __params__.get('imode') == 'suche':
    text = __dialog_imput_alphanum__(heading=__get_color_text__('lime','Suche ?'))
    __get_entries_and_next_page__('https://kinofox.su/index.php?do=search&subaction=search&search_start=0&full_search=0&result_from=1&story='+text,mode='post')

elif __params__.get('imode') == 'Release':
	
    Release = __params__.get('Release')
    url = __params__.get('url')
	
    req = __get_cfscrape_sess__(url=url,stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict=__get_url_specific_security_headers__(url))
	
    match = __regex_search__('Release Jahre.*?</ul>',req.text)
    if match:
        for url,title in __regex_findall__('href="([^"]+)">([^<]+)',match.group(0)):
            __add_item__(url=__base_url__+url,title=title,image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='get_dropdown_select_url',is_folder=True,is_playable=False)
    __end_of_directory__()

elif __params__.get('imode') == 'get_dropdown_select_url':	
	url = __params__.get('url')
	__get_entries_and_next_page__(url)


elif __params__.get('imode') == 'list_hosters':

    url = __params__.get('url')
    title = __params__.get('title')
    img = __params__.get('image')

    req = __get_cfscrape_sess__(url=url,stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict=__get_url_specific_security_headers__(url))
	
    for hoster_url in __regex_findall__('iframe src="([^"]+)',req.text):
        __add_item__(url=hoster_url,title=__get_color_text__('lime',title +' | '+__get_domain__(hoster_url).upper()),image=img,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='play_hoster',is_folder=False,is_playable=False)
    
    __end_of_directory__()

elif __params__.get('imode') == 'play_hoster':

	hoster_url = __params__.get('url')
	play_url = __get_resolved_url__(hoster_url)
	__set_resolved_url__(url=play_url)