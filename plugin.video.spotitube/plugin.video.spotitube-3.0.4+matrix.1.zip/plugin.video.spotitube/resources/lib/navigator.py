﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import random
import time
import _strptime
from datetime import datetime, date, timedelta
from urllib.parse import urlencode, quote_plus

from .common import *
from .utilities import Transmission


iTunesRegion = itunesCountry.lower() if itunesForceCountry and itunesCountry != '' else region.lower()
spotifyRegion = spotifyCountry.upper() if spotifyForceCountry and spotifyCountry != '' else region.upper()

if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

if myTOKEN == 'AIzaSy.................................':
	xbmc.executebuiltin('Addon.OpenSettings({})'.format(addon_id))


def mainMenu():
	addDir(translation(30601), artpic+'deepsearch.gif', {'mode': 'SearchDeezer'})
	addDir(translation(30602), artpic+'beatport.png', {'mode': 'beatportMain'})
	addDir(translation(30603), artpic+'billboard.png', {'mode': 'billboardMain'})
	addDir(translation(30604), artpic+'ddp_home.png', {'mode': 'ddpMain'})
	addDir(translation(30605), artpic+'hypem.png', {'mode': 'hypemMain'})
	addDir(translation(30606), artpic+'itunes.png', {'mode': 'itunesMain'})
	addDir(translation(30607), artpic+'official.png', {'mode': 'ocMain'})
	addDir(translation(30608), artpic+'shazam.png', {'mode': 'shazamMain'})
	addDir(translation(30609), artpic+'spotify.png', {'mode': 'spotifyMain'})
	addDir(translation(30610).format(str(cachePERIOD)), artpic+'remove.png', {'mode': 'clearCache'}, folder=False)
	if enableADJUSTMENT:
		addDir(translation(30611), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def beatportMain():
	content = Transmission().makeREQUEST(BASE_URL_BP, 'LOAD')
	content = content[content.find('<div class="mobile-menu-body">')+1:]
	content = content[:content.find('<!-- End Mobile Touch Menu -->')]
	match = re.compile(r'<a href="(.*?)" class="genre-drop-list__genre" data-name=.+?">(.*?)</a>', re.S).findall(content)
	addAutoPlayDir(translation(30620), artpic+'beatport.png', {'mode': 'listBeatportVideos', 'url': BASE_URL_BP+'/top-100'})
	for genreURL, genreTITLE in match:
		topUrl = BASE_URL_BP+genreURL+'/top-100'
		title = cleaning(genreTITLE)
		addAutoPlayDir(title, artpic+'beatport.png', {'mode': 'listBeatportVideos', 'url': topUrl})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDGenres+')')

def listBeatportVideos(url, TYPE, LIMIT):
	musicVideos = []
	musicIsolated = set()
	counter = 0
	PLT = cleanPlaylist() if TYPE == 'play' else None
	content = Transmission().makeREQUEST(url, 'LOAD')
	response = re.compile(r'(?s)window.Playables = (?P<json>{.+?)]};', re.S).findall(content)[0]
	DATA = json.loads(response+']}')
	for item in DATA['tracks']:
		artists = ', '.join([cleaning(artist['name']) for artist in item['artists']])
		song = cleaning(item['name'])
		if item.get('mix', '') and not 'original' in item.get('mix').lower():
			song += ' ['+cleaning(item['mix'])+']'
		plot = 'Artist:  '+artists+'[CR]'+'Song:  '+song
		firstTitle = artists+" - "+song
		try:
			released = time.strptime(item['date']['released'], '%Y-%m-%d')
			newDate = time.strftime('%d.%m.%Y', released)
			plot += '[CR]Date:  [COLOR deepskyblue]'+str(newDate)+'[/COLOR]'
			completeTitle = firstTitle+'   [COLOR deepskyblue]['+str(newDate)+'][/COLOR]'
		except: completeTitle = firstTitle
		try:
			images = list(dict.values(item['images']))
			thumb = images[0]['url']
			thumb = thumb.split('image_size')[0]+'image/'+thumb.split('/')[-1]
		except: thumb = artpic+'noimage.png'
		for snippet in blackList:
			if snippet.strip().lower() and snippet.strip().lower() in firstTitle.lower():
				continue
		musicVideos.append([firstTitle, completeTitle, thumb, plot])
	if TYPE == 'browse':
		for firstTitle, completeTitle, thumb, plot in musicVideos:
			counter += 1
			name = translation(30801).format(str(counter), completeTitle)
			addLink(name, thumb, {'mode': 'playTITLE', 'url': fitme(firstTitle)}, plot)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if forceView:
			xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')
	else:
		if int(LIMIT) > 0:
			musicVideos = musicVideos[:int(LIMIT)]
		random.shuffle(musicVideos)
		for firstTitle, completeTitle, thumb, plot in musicVideos:
			endUrl = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playTITLE', 'url': fitme(firstTitle)}))
			listitem = xbmcgui.ListItem(firstTitle)
			listitem.setArt({'icon': icon, 'thumb': thumb, 'poster': thumb})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(endUrl, listitem)
		xbmc.Player().play(PLT)

def billboardMain():
	addAutoPlayDir(translation(30630), artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/hot-100/'})
	addAutoPlayDir(translation(30631), artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/billboard-200/'})
	addAutoPlayDir(translation(30632), artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/billboard-global-200/'})
	addDir(translation(30633), artpic+'billboard.png', {'mode': 'listBillboardCharts', 'url': 'genre'})
	addDir(translation(30634), artpic+'billboard.png', {'mode': 'listBillboardCharts', 'url': 'country'})
	addDir(translation(30635), artpic+'billboard.png', {'mode': 'listBillboardCharts', 'url': 'other'})
	addDir(translation(30636), artpic+'billboard.png', {'mode': 'listBillboardCharts', 'url': 'archive'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBillboardCharts(SELECT):
	if SELECT == 'genre':
		addAutoPlayDir('Alternative', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/alternative-airplay/'})
		addAutoPlayDir('Country', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/country-songs/'})
		addAutoPlayDir('Dance/Club', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/dance-club-play-songs/'})
		addAutoPlayDir('Dance/Electronic', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/dance-electronic-songs/'})
		addAutoPlayDir('Gospel', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/gospel-songs/'})
		addAutoPlayDir('Latin', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/latin-songs/'})
		addAutoPlayDir('Pop', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/pop-songs/'})
		addAutoPlayDir('Rap', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/rap-song/'})
		addAutoPlayDir('R&B', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/r-and-b-songs/'})
		addAutoPlayDir('R&B/Hip-Hop', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/r-b-hip-hop-songs/'})
		addAutoPlayDir('Rhythmic', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/rhythmic-40/'})
		addAutoPlayDir('Rock', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/rock-songs/'})
		addAutoPlayDir('Smooth Jazz', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/jazz-songs/'})
		addAutoPlayDir('Soundtracks', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/soundtracks/'})
		addAutoPlayDir('Tropical', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/latin-tropical-airplay/'})
	elif SELECT == 'country':
		addAutoPlayDir('Argentina Hot-100', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/billboard-argentina-hot-100/'})
		addAutoPlayDir('Canada Hot-100', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/canadian-hot-100/'})
		addAutoPlayDir('Australia - Digital Song Sales', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/australia-digital-song-sales/'})
		addAutoPlayDir('Canadian - Digital Song Sales', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/hot-canada-digital-song-sales/'})
		addAutoPlayDir('Euro - Digital Song Sales', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/euro-digital-song-sales/'})
		addAutoPlayDir('France - Digital Song Sales', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/france-digital-song-sales/'})
		addAutoPlayDir('Germany - Songs', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/germany-songs/'})
		addAutoPlayDir('Italy - Digital Song Sales', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/italy-digital-song-sales/'})
		addAutoPlayDir('Spain - Digital Song Sales', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/spain-digital-song-sales/'})
		addAutoPlayDir('Switzerland - Digital Song Sales', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/switzerland-digital-song-sales/'})
		addAutoPlayDir('U.K. - Digital Song Sales', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/uk-digital-song-sales/'})
		addAutoPlayDir('World - Digital Song Sales', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/world-digital-song-sales/'})
	elif SELECT == 'other':
		addAutoPlayDir('Digital Song Sales', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/digital-song-sales/'})
		addAutoPlayDir('Streaming Songs', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/streaming-songs/'})
		addAutoPlayDir('Radio Songs', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/radio-songs/'})
		addAutoPlayDir('TOP Songs of the ’90s', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/greatest-billboards-top-songs-90s/'})
		addAutoPlayDir('TOP Songs of the ’80s', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/greatest-billboards-top-songs-80s/'})
		addAutoPlayDir('All Time Hot 100 Singles', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/greatest-hot-100-singles/'})
		addAutoPlayDir('All Time Greatest Alternative Songs', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/greatest-alternative-songs/'})
		addAutoPlayDir('All Time Greatest Country Songs', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/greatest-country-songs/'})
		addAutoPlayDir('All Time Greatest Latin Songs', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/greatest-hot-latin-songs/'})
		addAutoPlayDir('All Time Greatest Pop Songs', artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': BASE_URL_BB+'/charts/greatest-of-all-time-pop-songs/'})
	elif SELECT == 'archive':
		addDir('Hot 100 Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/hot-100-songs/'}) # bis 2006
		addDir('Global 200 Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/billboard-global-200/'}) # bis 2021
		addDir('Streaming Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/streaming-songs/'}) # bis 2013
		addDir('Radio Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/radio-songs/'}) # bis 2006
		addDir('Digital Song Sales', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/digital-songs/'}) # bis 2006
		addDir('Country Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/hot-country-songs/'}) # bis 2002
		addDir('Dance/Electronic Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/hot-dance-electronic-songs/'}) # bis 2013
		addDir('Gospel Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/hot-gospel-songs/'}) # bis 2006
		addDir('Latin Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/hot-latin-songs/'}) # bis 2006
		addDir('Pop Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/pop-songs/'}) # bis 2008
		addDir('Rap Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/hot-rap-songs/'}) # bis 2009
		addDir('R&B Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/hot-r-and-and-b-songs/'}) # bis 2013
		addDir('R&B/Hip-Hop Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/hot-r-and-and-b-hip-hop-songs/'}) # bis 2002
		addDir('Rhytmic Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/rhythmic-songs/'}) # bis 2006
		addDir('Rock Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/hot-rock-songs/'}) # bis 2009
		addDir('Smooth Jazz Songs', artpic+'billboard.png', {'mode': 'listBillboardArchive', 'url': BASE_URL_BB+'/charts/year-end/smooth-jazz-songs/'}) # bis 2006
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDGenres+')')

def listBillboardArchive(url):
	content = Transmission().makeREQUEST(url, 'LOAD')
	result = re.findall(r'All Year-end Charts(.*?)</ul>', content, re.S)[0]
	match = re.compile(r'href="('+BASE_URL_BB+'[^"]+).+?>([^<]+?)</a>', re.S).findall(result)
	for url2, title2 in match:
		addAutoPlayDir(title2.strip(), artpic+'billboard.png', {'mode': 'listBillboardVideos', 'url': url2})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDPlaylists+')')

def listBillboardVideos(url, TYPE, LIMIT):
	musicVideos = []
	startURL = url
	counter = 0
	PLT = cleanPlaylist() if TYPE == 'play' else None
	content = Transmission().makeREQUEST(url, 'LOAD')
	spl = content.split('class="o-chart-results-list-row-container">')
	for i in range(1,len(spl),1):
		entry = spl[i]
		song = re.compile(r'id="title-of-a-story" class="c-title.+?>([^<]+?)</', re.S).findall(entry)[0]
		song = re.sub(r'\<.*?>', '', song)
		song = cleaning(song)
		artist = re.compile(r'id="title-of-a-story" class="c-title.+?<span class="c-label.+?>([^<]+?)</span>', re.S).findall(entry)[0]
		artist = re.sub(r'\<.*?>', '', artist)
		artist = cleaning(artist)
		plot = 'Artist:  '+artist+'[CR]'+'Song:  '+song
		firstTitle = artist+" - "+song
		completeTitle = firstTitle
		if not 'charts/greatest' in startURL and not 'charts/year-end' in startURL:
			results = re.findall(r'<div class="a-chart-plus-minus-icon">(.+?)<div class="charts-result-detail', entry, re.S)
			for item in results:
				try:
					lastWeek = re.compile(r'<span class="c-label.+?>([^<]+?)</span>', re.S).findall(item)[0].strip()
					weeksChart = re.compile(r'<span class="c-label.+?>([^<]+?)</span>', re.S).findall(item)[2].strip()
					plot += '[CR]Rank:  [COLOR deepskyblue]LW = {}|weeksIN = {}[/COLOR]'.format(str(lastWeek).replace('-', '~'), str(weeksChart).replace('-', '~'))
					completeTitle = '{}   [COLOR deepskyblue][LW: {}|weeksIN: {}][/COLOR]'.format(firstTitle, str(lastWeek).replace('-', '~'), str(weeksChart).replace('-', '~'))
				except: pass
		try:
			img = re.compile(r'data-lazy-src="(https?://charts-static.billboard.com.+?(?:\.jpg|\.jpeg|\.png))', re.S).findall(entry)[0]
			thumb = re.sub(r'-[0-9]+x[0-9]+', '-480x480', img).strip() # -53x53.jpg || -87x87.jpg || -106x106.jpg || -180x180.jpg || -224x224.jpg || -344x344.jpg
		except: thumb = artpic+'noimage.png'
		for snippet in blackList:
			if snippet.strip().lower() and snippet.strip().lower() in firstTitle.lower():
				continue
		musicVideos.append([firstTitle, completeTitle, thumb, plot])
	if TYPE == 'browse':
		for firstTitle, completeTitle, thumb, plot in musicVideos:
			counter += 1
			name = translation(30801).format(str(counter), completeTitle)
			addLink(name, thumb, {'mode': 'playTITLE', 'url': fitme(firstTitle)}, plot)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if forceView:
			xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')
	else:
		if int(LIMIT) > 0:
			musicVideos = musicVideos[:int(LIMIT)]
		random.shuffle(musicVideos)
		for firstTitle, completeTitle, thumb, plot in musicVideos:
			endUrl = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playTITLE', 'url': fitme(firstTitle)}))
			listitem = xbmcgui.ListItem(firstTitle)
			listitem.setArt({'icon': icon, 'thumb': thumb, 'poster': thumb})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(endUrl, listitem)
		xbmc.Player().play(PLT)

def ddpMain():
	content = Transmission().makeREQUEST(BASE_URL_DDP, 'LOAD')
	result = re.findall(r'<nav id="menu">(.*?)</nav>', content, re.S)[0]
	addDir(translation(30650), artpic+'ddp_dance.png', {'mode': 'blankFUNC', 'url': '00'}, folder=False)
	addAutoPlayDir(translation(30651), artpic+'ddp_dance.png', {'mode': 'listDdpVideos', 'url': BASE_URL_DDP+'/top-30/video'})
	match = re.compile(r'<a href="([^"]+)">(.*?)</a>', re.S).findall(result)
	for url2, title2 in match:
		title2 = cleaning(title2)
		if not title2.lower().startswith(('ddp', 'top 30')):
			if not 'schlager' in url2.lower():
				if title2.lower() in ['top 100','hot 50', 'neueinsteiger']:
					addAutoPlayDir('..... '+title2, artpic+'ddp_dance.png', {'mode': 'listDdpVideos', 'url': BASE_URL_DDP+url2})
				elif title2.lower() in ['highscores', 'jahrescharts']:
					addDir('..... '+title2, artpic+'ddp_dance.png', {'mode': 'listDdpYearCharts', 'url': BASE_URL_DDP+url2})
	addDir(translation(30652), artpic+'ddp_schlager.png', {'mode': 'blankFUNC', 'url': '00'}, folder=False)
	for url2, title2 in match:
		title2 = cleaning(title2)
		if not title2.lower().startswith(('ddp', 'top 30')):
			if 'schlager' in url2.lower():
				if title2.lower() in ['top 100','hot 50', 'neueinsteiger']:
					addAutoPlayDir('..... '+title2, artpic+'ddp_schlager.png', {'mode': 'listDdpVideos', 'url': BASE_URL_DDP+url2})
				elif title2.lower() in ['highscores', 'jahrescharts']:
					addDir('..... '+title2, artpic+'ddp_schlager.png', {'mode': 'listDdpYearCharts', 'url': BASE_URL_DDP+url2})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDGenres+')')

def listDdpYearCharts(url):
	musicVideos = []
	content = Transmission().makeREQUEST(url, 'LOAD')
	result = re.findall(r'<div class="year-selection">(.*?)</div>', content, re.S)[0]
	musicVideos = re.compile(r'<a href="([^"]+).*?>([^<]+)</a>', re.S).findall(result)
	for url2, title2 in sorted(musicVideos, key=lambda d:d[1], reverse=True):
		thumb = artpic+'ddp_dance.png' if 'dance' in url.lower() else artpic+'ddp_schlager.png'
		addAutoPlayDir(cleaning(title2), thumb, {'mode': 'listDdpVideos', 'url': BASE_URL_DDP+url2})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDPlaylists+')')

def listDdpVideos(url, TYPE, LIMIT):
	musicVideos = []
	musicIsolated = set()
	PLT = cleanPlaylist() if TYPE == 'play' else None
	content = Transmission().makeREQUEST(url, 'LOAD')
	if 'highscores' in url or 'jahrescharts' in url:
		result = re.findall(r'<div class="charts big" style(.*?)<div class="charts big mobile" style', content, re.S)[0]
	else:
		result = re.findall(r'<div class="charts big mobile" style(.*?)<div class="footer">', content, re.S)[-1]
	spl = result.split('<div class="entry">')
	for i in range(1,len(spl),1):
		entry = spl[i]
		rank = re.compile(r'<div class="rank">(.*?)</div>', re.S).findall(entry)
		artist = re.compile(r'<div class="artist">(.*?)</div>', re.S).findall(entry)
		song = re.compile(r'<div class="title">(.*?)</div>', re.S).findall(entry)
		if not artist or not song:
			continue
		artist = TitleCase(cleaning(artist[0]))
		song = TitleCase(cleaning(song[0]))
		plot = 'Artist:  '+artist+'[CR]'+'Song:  '+song
		firstTitle = artist+" - "+song
		if firstTitle in musicIsolated:
			continue
		musicIsolated.add(firstTitle)
		completeTitle = None
		if 'highscores' in url or 'jahrescharts' in url:
			Points = re.compile(r'<div class="s-pkt"><div>(.*?)</div>', re.S).findall(entry)
			Week = re.compile(r'<div class="s-wk"><div>(.*?)</div>', re.S).findall(entry)
			if Week and not Points:
				plot += '[CR]Week:  [COLOR deepskyblue]{}[/COLOR]'.format(str(Week[0].strip()))
				completeTitle = '{}   [COLOR deepskyblue][WK: {}][/COLOR]'.format(firstTitle, str(Week[0].strip()))
			elif Week and Points:
				plot += '[CR]Points:  [COLOR deepskyblue]{}[/COLOR][CR]Week:  [COLOR deepskyblue]{}[/COLOR]'.format(str(Points[0].strip()), str(Week[0].strip()))
				completeTitle = '{}   [COLOR deepskyblue][PT: {}|WK: {}][/COLOR]'.format(firstTitle, str(Points[0].strip()), str(Week[0].strip()))
		else:
			try:
				newRE = re.compile(r'<div class="value">(.*?)</div>', re.S).findall(entry)[0].strip()
				oneWeek = re.compile(r'<div class="value">(.*?)</div>', re.S).findall(entry)[1].strip()
				twoWeek = re.compile(r'<div class="value">(.*?)</div>', re.S).findall(entry)[2].strip()
				threeWeek = re.compile(r'<div class="value">(.*?)</div>', re.S).findall(entry)[3].strip()
				if newRE in ['NEU', 'RE']:
					plot += '[CR]Rank:  [COLOR deepskyblue]'+str(newRE)+'[/COLOR]'
					completeTitle = firstTitle+'   [COLOR deepskyblue]['+str(newRE)+'][/COLOR]'
				else:
					plot += '[CR]Rank:  [COLOR deepskyblue]LW = {}|2W = {}|3W = {}[/COLOR]'.format(str(oneWeek).replace('-', '~'), str(twoWeek).replace('-', '~'), str(threeWeek).replace('-', '~'))
					completeTitle = '{}   [COLOR deepskyblue][LW: {}|2W: {}|3W: {}][/COLOR]'.format(firstTitle, str(oneWeek).replace('-', '~'), str(twoWeek).replace('-', '~'), str(threeWeek).replace('-', '~'))
			except: pass
		if completeTitle is None: completeTitle = firstTitle
		try:
			thumb = re.compile(r'<div class="cover".+?//poolposition.mp3([^"]+)"', re.S).findall(entry)[0]
			thumb = 'https://poolposition.mp3'+thumb.split('&width')[0]
		except: thumb = artpic+'noimage.png'
		for snippet in blackList:
			if snippet.strip().lower() and snippet.strip().lower() in firstTitle.lower():
				continue
		musicVideos.append([rank[0].strip(), firstTitle, completeTitle, thumb, plot])
	musicVideos = sorted(musicVideos, key=lambda d: int(d[0]), reverse=False)
	if TYPE == 'browse':
		for rank, firstTitle, completeTitle, thumb, plot in musicVideos:
			name = translation(30801).format(str(rank), completeTitle)
			addLink(name, thumb, {'mode': 'playTITLE', 'url': fitme(firstTitle)}, plot)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if forceView:
			xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')
	else:
		if int(LIMIT) > 0:
			musicVideos = musicVideos[:int(LIMIT)]
		random.shuffle(musicVideos)
		for rank, firstTitle, completeTitle, thumb, plot in musicVideos:
			endUrl = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playTITLE', 'url': fitme(firstTitle)}))
			listitem = xbmcgui.ListItem(firstTitle)
			listitem.setArt({'icon': icon, 'thumb': thumb, 'poster': thumb})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(endUrl, listitem)
		xbmc.Player().play(PLT)

def hypemMain():
	addAutoPlayDir(translation(30660), artpic+'hypem.png', {'mode': 'listHypemVideos', 'url': BASE_URL_HM+'/popular?ax=1&sortby=shuffle'})
	addAutoPlayDir(translation(30661), artpic+'hypem.png', {'mode': 'listHypemVideos', 'url': BASE_URL_HM+'/popular/lastweek?ax=1&sortby=shuffle'})
	addDir(translation(30662), artpic+'hypem.png', {'mode': 'listHypemMachine'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listHypemMachine():
	for i in range(1, 201, 1):
		dt = date.today()
		while dt.weekday() != 0:
			dt -= timedelta(days=1)
		dt -= timedelta(weeks=i)
		months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
		month = months[int(dt.strftime('%m')) - 1]
		addAutoPlayDir(dt.strftime('%d. %b - %Y').replace('Mar', translation(30663)).replace('May', translation(30664)).replace('Oct', translation(30665)).replace('Dec', translation(30666)),
			artpic+'hypem.png', {'mode': 'listHypemVideos', 'url': '{}/popular/week:{}-{}?ax=1&sortby=shuffle'.format(BASE_URL_HM, month, dt.strftime('%d-%Y'))})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDPlaylists+')')

def listHypemVideos(url, TYPE, LIMIT):
	musicVideos = []
	musicIsolated = set()
	counter = 0
	PLT = cleanPlaylist() if TYPE == 'play' else None
	content = Transmission().makeREQUEST(url, 'LOAD')
	response = re.compile(r'id="displayList-data">(.*?)</', re.S).findall(content)[0]
	DATA = json.loads(response)
	for item in DATA['tracks']:
		artist = cleaning(item['artist'])
		song = cleaning(item['song'])
		plot = 'Artist:  '+artist+'[CR]'+'Song:  '+song
		firstTitle = artist+" - "+song
		if firstTitle in musicIsolated or artist == "":
			continue
		musicIsolated.add(firstTitle)
		match = re.compile(r'href="/track/'+item['id']+'/.+?background:url\\((.+?)\\)', re.S).findall(content)
		thumb = match[0] if match else artpic+'noimage.png' #.replace('_320.jpg)', '_500.jpg')
		for snippet in blackList:
			if snippet.strip().lower() and snippet.strip().lower() in firstTitle.lower():
				continue
		musicVideos.append([firstTitle, thumb, plot])
	if TYPE == 'browse':
		for firstTitle, thumb, plot in musicVideos:
			counter += 1
			name = translation(30801).format(str(counter), firstTitle)
			addLink(name, thumb, {'mode': 'playTITLE', 'url': fitme(firstTitle)}, plot)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if forceView:
			xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')
	else:
		if int(LIMIT) > 0:
			musicVideos = musicVideos[:int(LIMIT)]
		random.shuffle(musicVideos)
		for firstTitle, thumb, plot in musicVideos:
			endUrl = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playTITLE', 'url': fitme(firstTitle)}))
			listitem = xbmcgui.ListItem(firstTitle)
			listitem.setArt({'icon': icon, 'thumb': thumb, 'poster': thumb})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(endUrl, listitem)
		xbmc.Player().play(PLT)

def itunesMain():
	content = Transmission().makeREQUEST('https://itunes.apple.com/{}/genre/music/id34'.format(iTunesRegion), 'LOAD')
	content = content[content.find('id="genre-nav"'):]
	content = content[:content.find('</div>')]
	match = re.compile(r'<li><a href="https?://(?:itunes.|music.)apple.com/.+?/genre/.+?/id(.*?)"(.*?)title=".+?">(.*?)</a>', re.S).findall(content)
	addAutoPlayDir(translation(30680), artpic+'itunes.png', {'mode': 'listItunesVideos', 'url': '0'})
	for genreID, genreTYPE, genreTITLE in match:
		title = cleaning(genreTITLE)
		if 'class="top-level-genre"' in genreTYPE:
			if itunesShowSubGenres:
				title = translation(30681).format(title)
			addAutoPlayDir(title, artpic+'itunes.png', {'mode': 'listItunesVideos', 'url': genreID})
		elif itunesShowSubGenres:
			addAutoPlayDir('..... '+title, artpic+'itunes.png', {'mode': 'listItunesVideos', 'url': genreID})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDGenres+')')

def listItunesVideos(genreID, TYPE, LIMIT):
	musicVideos = []
	musicIsolated = set()
	counter = 0
	PLT = cleanPlaylist() if TYPE == 'play' else None
	url = 'https://itunes.apple.com/{}/rss/topsongs/limit=100'.format(iTunesRegion)
	if genreID != '0':
		url += '/genre='+genreID
	url += '/explicit=true/json'
	content = Transmission().makeREQUEST(url)
	for item in content['feed']['entry']:
		artist = cleaning(item['im:artist']['label'])
		song = cleaning(item['im:name']['label'])
		plot = 'Artist:  '+artist+'[CR]'+'Song:  '+song
		firstTitle = artist+" - "+song
		if firstTitle in musicIsolated:
			continue
		musicIsolated.add(firstTitle)
		try:
			newDate = item['im:releaseDate']['attributes']['label']
			plot += '[CR]Date:  [COLOR deepskyblue]'+str(newDate)+'[/COLOR]'
			completeTitle = firstTitle+'   [COLOR deepskyblue]['+str(newDate)+'][/COLOR]'
		except: completeTitle = firstTitle
		try: thumb = item['im:image'][2]['label'].replace('/170x170bb.png', '/512x512bb.jpg').replace('/170x170bb.jpg', '/512x512bb.jpg')
		except: thumb = artpic+'noimage.png'
		for snippet in blackList:
			if snippet.strip().lower() and snippet.strip().lower() in firstTitle.lower():
				continue
		musicVideos.append([firstTitle, completeTitle, thumb, plot])
	if TYPE == 'browse':
		for firstTitle, completeTitle, thumb, plot in musicVideos:
			counter += 1
			name = translation(30801).format(str(counter), completeTitle)
			addLink(name, thumb, {'mode': 'playTITLE', 'url': fitme(firstTitle)}, plot)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if forceView:
			xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')
	else:
		if int(LIMIT) > 0:
			musicVideos = musicVideos[:int(LIMIT)]
		random.shuffle(musicVideos)
		for firstTitle, completeTitle, thumb, plot in musicVideos:
			endUrl = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playTITLE', 'url': fitme(firstTitle)}))
			listitem = xbmcgui.ListItem(firstTitle)
			listitem.setArt({'icon': icon, 'thumb': thumb, 'poster': thumb})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(endUrl, listitem)
		xbmc.Player().play(PLT)

def ocMain():
	addAutoPlayDir(translation(30700), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/singles-chart/'})
	addAutoPlayDir(translation(30701), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/uk-top-40-singles-chart/'})
	addAutoPlayDir(translation(30702), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/singles-chart-update/'})
	addAutoPlayDir(translation(30703), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/singles-downloads-chart/'})
	addAutoPlayDir(translation(30704), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/singles-sales-chart/'})
	addAutoPlayDir(translation(30705), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/audio-streaming-chart/'})
	addAutoPlayDir(translation(30706), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/dance-singles-chart/'})
	addAutoPlayDir(translation(30708), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/official-hip-hop-and-r-and-b-singles-chart/'})
	addAutoPlayDir(translation(30709), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/rock-and-metal-singles-chart/'})
	addAutoPlayDir(translation(30710), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/irish-singles-chart/'})
	addAutoPlayDir(translation(30711), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/scottish-singles-chart/'})
	addAutoPlayDir(translation(30712), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/end-of-year-singles-chart/'})
	addAutoPlayDir(translation(30713), artpic+'official.png', {'mode': 'listOcVideos', 'url': BASE_URL_OC+'/charts/physical-singles-chart/'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDGenres+')')

def listOcVideos(url, TYPE, LIMIT):
	debug_MS("(navigator.listOcVideos) ### url = {0} || TYPE = {1} || LIMIT = {2} ###".format(url, TYPE, LIMIT))
	musicVideos = []
	musicIsolated = set()
	counter = 0
	PLT = cleanPlaylist() if TYPE == 'play' else None
	content = Transmission().makeREQUEST(url, 'LOAD')
	result = re.findall(r'<section class="chart">(.*?)</section>', content, re.S)[0]
	spl = result.split('<div class="track">')
	for i in range(1,len(spl),1):
		entry = spl[i]
		song = re.compile(r'<div class="title">(.*?)</div>', re.S).findall(entry)
		artist = re.compile(r'<div class="artist">(.*?)</div>', re.S).findall(entry)
		if not song or not artist:
			continue
		song = re.sub(r'\<.*?>', '', song[0])
		song = TitleCase(cleaning(song))
		artist = re.sub(r'\<.*?>', '', artist[0])
		artist = artist.split('/')[0] if '/' in artist else artist
		artist = TitleCase(cleaning(artist))
		plot = 'Artist:  '+artist+'[CR]'+'Song:  '+song
		firstTitle = artist+" - "+song
		photo = re.compile(r'<div class="cover".+?<img src="([^"]+)"', re.S).findall(entry)[0]
		if 'amazon.com' in photo or 'coverartarchive.org' in photo:
			thumb = photo.split('img/small?url=')[1].replace('http://ecx.images-amazon.com', 'https://m.media-amazon.com').replace('L._SL75_', 'L')
		elif '/img/small?url=/images/artwork/' in photo:
			thumb = photo.replace('/img/small?url=', '')
		else: thumb = artpic+'noimage.png'
		for snippet in blackList:
			if snippet.strip().lower() and snippet.strip().lower() in firstTitle.lower():
				continue
		musicVideos.append([firstTitle, thumb, plot])
	if TYPE == 'browse':
		for firstTitle, thumb, plot in musicVideos:
			counter += 1
			name = translation(30801).format(str(counter), firstTitle)
			addLink(name, thumb, {'mode': 'playTITLE', 'url': fitme(firstTitle)}, plot)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if forceView:
			xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')
	else:
		if int(LIMIT) > 0:
			musicVideos = musicVideos[:int(LIMIT)]
		random.shuffle(musicVideos)
		for firstTitle, thumb, plot in musicVideos:
			endUrl = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playTITLE', 'url': fitme(firstTitle)}))
			listitem = xbmcgui.ListItem(firstTitle)
			listitem.setArt({'icon': icon, 'thumb': thumb, 'poster': thumb})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(endUrl, listitem)
		xbmc.Player().play(PLT)

def shazamMain():
	Supported = ['AU', 'BR', 'CA', 'FR', 'DE', 'IT', 'MX', 'RU', 'ZA', 'ES', 'TR', 'GB', 'US'] # these lists are supported for genrefolders
	addAutoPlayDir(translation(30730), artpic+'shazam.png', {'mode': 'listShazamVideos', 'url': BASE_URL_SZ+'/ip-global-chart?pageSize=200&startFrom=0'})
	for pick in Transmission().countries_alpha():
		if any(x in pick['cd'] for x in Supported):
			addDir(translation(30731).format(pick['ne']), artpic+'shazam.png', {'mode': 'listShazamGenres', 'url': pick['cd']})
		else:
			addAutoPlayDir(translation(30732).format(pick['ne']), artpic+'shazam.png', {'mode': 'listShazamVideos', 'url': '{}/ip-country-chart-{}?pageSize=200&startFrom=0'.format(BASE_URL_SZ, pick['cd'])})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDGenres+')')

def listShazamGenres(COUNTRY):
	GENRES = [{'ne': 'Pop','cd': '1'},{'ne': 'Hip-Hop/Rap','cd': '2'},{'ne': 'Dance','cd': '3'},{'ne': 'Electronic','cd': '4'},{'ne': 'R&B/Soul','cd': '5'},{'ne': 'Alternative','cd': '6'},
		{'ne': 'Rock','cd': '7'},{'ne': 'Latin','cd': '8'},{'ne': 'Film, TV & Stage','cd': '9'},{'ne': 'Country','cd': '10'},{'ne': 'AfroBeats','cd': '11'},{'ne': 'Worldwide','cd': '12'},
		{'ne': 'Reggae/Dancehall','cd': '13'},{'ne': 'House','cd': '14'},{'ne': 'K-Pop','cd': '15'},{'ne': 'French Pop','cd': '16'},{'ne': 'Singer/Songwriter','cd': '17'}]
	addAutoPlayDir(translation(30733).format(COUNTRY), artpic+'shazam.png', {'mode': 'listShazamVideos', 'url': '{}/ip-country-chart-{}?pageSize=200&startFrom=0'.format(BASE_URL_SZ, COUNTRY)})
	for elem in sorted(GENRES, key=lambda n:n['ne'], reverse=False):
		addAutoPlayDir(elem['ne'], artpic+'shazam.png', {'mode': 'listShazamVideos', 'url': '{}/genre-country-chart-{}-{}?pageSize=200&startFrom=0'.format(BASE_URL_SZ, COUNTRY, elem['cd'])})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDGenres+')')

def listShazamVideos(url, TYPE, LIMIT):
	musicVideos = []
	musicIsolated = set()
	counter = 0
	PLT = cleanPlaylist() if TYPE == 'play' else None
	content = Transmission().makeREQUEST(url)
	for item in content.get('tracks', []):
		artist = cleaning(item['subtitle'])
		song = cleaning(item['title'])
		ATID = item['artists'][0].get('adamid', '') if item.get('artists', '') and 'adamid' in str(item.get('artists')) else None
		# https://www.shazam.com/services/amapi/v1/catalog/GB/artists/487277?extend=origin&views=top-songs%2Ctop-music-videos = ATID
		plot = 'Artist:  '+artist+'[CR]'+'Song:  '+song
		firstTitle = artist+" - "+song
		if firstTitle in musicIsolated:
			continue
		musicIsolated.add(firstTitle)
		try:
			thumb = (item['images'].get('coverarthq', '') or item['images'].get('coverart', ''))
			thumb = thumb.replace('/400x400cc.', '/500x500cc.')
		except: thumb = artpic+'noimage.png'
		for snippet in blackList:
			if snippet.strip().lower() and snippet.strip().lower() in firstTitle.lower():
				continue
		musicVideos.append([firstTitle, thumb, plot])
	if TYPE == 'browse':
		for firstTitle, thumb, plot in musicVideos:
			counter += 1
			name = translation(30801).format(str(counter), firstTitle)
			addLink(name, thumb, {'mode': 'playTITLE', 'url': fitme(firstTitle)}, plot)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if forceView:
			xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')
	else:
		if int(LIMIT) > 0:
			musicVideos = musicVideos[:int(LIMIT)]
		random.shuffle(musicVideos)
		for firstTitle, thumb, plot in musicVideos:
			endUrl = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playTITLE', 'url': fitme(firstTitle)}))
			listitem = xbmcgui.ListItem(firstTitle)
			listitem.setArt({'icon': icon, 'thumb': thumb, 'poster': thumb})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(endUrl, listitem)
		xbmc.Player().play(PLT)

def spotifyMain():
	addDir(translation(30750), artpic+'spotify.png', {'mode': 'listSpotifyPlaylists', 'url': '{}/views/charts-regional?platform=web&country={}&offset=0&limit=50'.format(BASE_URL_SY, spotifyRegion)})
	addDir(translation(30751), artpic+'spotify.png', {'mode': 'listSpotifyPlaylists', 'url': '{}/views/charts-viral?platform=web&country={}&offset=0&limit=50'.format(BASE_URL_SY, spotifyRegion)})
	addDir(translation(30752), artpic+'spotify.png', {'mode': 'listSpotifyPlaylists', 'url': '{}/views/charts-regional-weekly?platform=web&country={}&offset=0&limit=50'.format(BASE_URL_SY, spotifyRegion)})
	addDir(translation(30753), artpic+'spotify.png', {'mode': 'listSpotifyPlaylists', 'url': '{}/views/charts-featured?platform=web&country={}&offset=0&limit=50'.format(BASE_URL_SY, spotifyRegion)})
	addDir(translation(30754), artpic+'spotify.png', {'mode': 'listSpotifyPlaylists', 'url': '{}/users/spotify/playlists?platform=web&country={}&offset=0&limit=50'.format(BASE_URL_SY, spotifyRegion)})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSpotifyPlaylists(url):
	resource = '' if 'users/' in url else 'content'
	for item in Transmission().user_playlists(url, resource):
		PID = item['id']
		name = cleaning(item['name'])
		plot = (cleaning(re.sub(r'\<.*?>', '', item.get('description', ''))) or "...")
		total = item['tracks']['total'] if item.get('tracks', '') and item['tracks'].get('total', '') else 0
		try: thumb = item['images'][0]['url']
		except: thumb = artpic+'noimage.png'
		addAutoPlayDir(name, thumb, {'mode': 'listSpotifyVideos', 'url': PID}, plot)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDPlaylists+')')

def listSpotifyVideos(url, TYPE, LIMIT):
	musicVideos = []
	musicIsolated = set()
	counter = 0
	PLT = cleanPlaylist() if TYPE == 'play' else None
	for item in Transmission().playlist_tracks(url, spotifyRegion):
		song = cleaning(item['track']['name']) if item.get('track', '') and item['track'].get('name', '') else None
		if item.get('track', '') is None or song is None: continue
		composers = [cleaning(at.get('name', '')) for at in item['track'].get('artists', [])]
		artist = composers[0]
		for ii, value in enumerate(composers):
			if 1 <= ii <= 2: ### Listenauswahl der Composers liegt zwischen Nummer:1-2 ###
				artist = artist + ', ' + value
			else: pass
		popular = item['track']['popularity'] if item.get('track', '') and item['track'].get('popularity', '') else None
		TID = item['track']['id'] if item.get('track', '') and item['track'].get('id', '') else 0
		plot = 'Artist:  '+artist+'[CR]'+'Song:  '+song
		firstTitle = artist+" - "+song
		if firstTitle in musicIsolated:
			continue
		musicIsolated.add(firstTitle)
		completeTitle = firstTitle
		if str(item['track']['album']['release_date'])[:4].isdigit() and len(str(item['track']['album']['release_date'])[:10]) == 10:
			released = datetime(*(time.strptime(item['track']['album']['release_date'][:10], '%Y{0}%m{0}%d'.format('-'))[0:6])) # 2022-07-15
			newDate = released.strftime('%d{0}%m{0}%Y').format('.')
			plot += '[CR]Date:  [COLOR deepskyblue]'+str(newDate)+'[/COLOR]'
			completeTitle = firstTitle+'   [COLOR deepskyblue]['+str(newDate)+'][/COLOR]'
		if popular:
			plot += '[CR]Fame:  [COLOR orangered]'+str(popular)+'[/COLOR]'
		try: thumb = item['track']['album']['images'][0]['url']
		except: thumb = artpic+'noimage.png'
		for snippet in blackList:
			if snippet.strip().lower() and snippet.strip().lower() in firstTitle.lower():
				continue
		musicVideos.append([firstTitle, completeTitle, thumb, plot])
	if TYPE == 'browse':
		for firstTitle, completeTitle, thumb, plot in musicVideos:
			counter += 1
			name = translation(30801).format(str(counter), completeTitle)
			addLink(name, thumb, {'mode': 'playTITLE', 'url': fitme(firstTitle)}, plot)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if forceView:
			xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')
	else:
		if int(LIMIT) > 0:
			musicVideos = musicVideos[:int(LIMIT)]
		random.shuffle(musicVideos)
		for firstTitle, completeTitle, thumb, plot in musicVideos:
			endUrl = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playTITLE', 'url': fitme(firstTitle)}))
			listitem = xbmcgui.ListItem(firstTitle)
			listitem.setArt({'icon': icon, 'thumb': thumb, 'poster': thumb})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(endUrl, listitem)
		xbmc.Player().play(PLT)

def SearchDeezer():
	keyword = None
	someReceived = False
	keyword = dialog.input(translation(30770), type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
	if keyword: keyword = quote_plus(keyword, safe='')
	else: return
	FOUNDATION = [
		{'action': 'artistSEARCH', 'conv': 'strukturARTIST', 'name': translation(30771), 'slug': 'artist', 'turn': 'listDeezerSelection'},
		{'action': 'trackSEARCH', 'conv': 'strukturTRACK', 'name': translation(30772), 'slug': 'track', 'turn': 'listDeezerVideos'},
		{'action': 'albumSEARCH', 'conv': 'strukturALBUM', 'name': translation(30773), 'slug': 'album', 'turn': 'listDeezerSelection'},
		{'action': 'playlistSEARCH', 'conv': 'strukturPLAYLIST', 'name': translation(30774), 'slug': 'playlist', 'turn': 'listDeezerSelection'},
		{'action': 'userlistSEARCH', 'conv': 'strukturUSERLIST', 'name': translation(30775), 'slug': 'user', 'turn': 'listDeezerSelection'}]
	for elem in FOUNDATION:
		elem['conv'] = Transmission().makeREQUEST('{0}/{1}?q={2}&limit={3}&strict=on&output=json&index=0'.format(BASE_URL_DZ, elem['slug'], keyword, deezerSearchDisplay))
		if elem['slug'] == 'track' and elem['conv']['total'] != 0:
			addAutoPlayDir(elem['name'], artpic+elem['slug']+'.png', {'mode': elem['turn'], 'url': keyword, 'extras': elem['slug'], 'transmit': icon})
			someReceived = True
		elif elem['slug'] in ['artist', 'album', 'playlist', 'user'] and elem['conv']['total'] != 0:
			addDir(elem['name'], artpic+elem['slug']+'.png', {'mode': elem['turn'], 'url': keyword, 'extras': elem['slug']})
			someReceived = True
	if not someReceived:
		addDir(translation(30776), artpic+'noresults.png', {'mode': 'root', 'url': keyword})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listDeezerSelection(url, EXTRA):
	musicVideos = []
	musicIsolated = set()
	if url.startswith(BASE_URL_DZ):
		content = Transmission().makeREQUEST(url)
	else:
		content = Transmission().makeREQUEST('{0}/{1}?q={2}&limit={3}&strict=on&output=json&index=0'.format(BASE_URL_DZ, EXTRA, url, deezerSearchDisplay))
	for item in content['data']:
		artist = cleaning(item['artist']['name']) if EXTRA == 'album' else cleaning(item['name']) if EXTRA == 'artist' else TitleCase(cleaning(item['title'])) if EXTRA == 'playlist' else None
		album = cleaning(item['title']) if EXTRA == 'album' else None
		user = TitleCase(cleaning(item['user']['name'])) if EXTRA == 'playlist' else TitleCase(cleaning(item['name'])) if EXTRA == 'user' else None
		numbers = str(item['nb_tracks']) if EXTRA in ['album', 'playlist'] else str(item['nb_fan']) if EXTRA == 'artist' else None
		version = cleaning(item['record_type']).title() if EXTRA == 'album' else None
		try:
			thumb = item['picture_big'] if EXTRA in ['artist', 'playlist', 'user'] else item['cover_big']
			if EXTRA in ['artist', 'user'] and thumb.endswith(EXTRA+'//500x500-000000-80-0-0.jpg'):
				thumb = artpic+'noavatar.gif'
		except:
			thumb = artpic+'noavatar.gif' if EXTRA in ['artist', 'user'] else artpic+'noimage.png'
		tracksUrl = item['tracklist'].split('top?limit=')[0]+'top?limit={0}&index=0'.format(deezerVideosDisplay) if EXTRA == 'artist' else item['tracklist']+'?limit={0}&index=0'.format(deezerVideosDisplay)
		special = artist+" - "+album if EXTRA == 'album' else artist.strip().lower() if EXTRA == 'artist' else artist+" - "+user if EXTRA == 'playlist' else user
		if special in musicIsolated:
			continue
		musicIsolated.add(special)
		musicVideos.append([numbers, artist, album, user, version, tracksUrl, special, thumb])
	musicVideos = sorted(musicVideos, key=lambda d:int(d[0]), reverse=True) if EXTRA == 'artist' else musicVideos
	for numbers, artist, album, user, version, tracksUrl, special, thumb in musicVideos:
		if EXTRA == 'artist':
			name = translation(30777).format(artist, numbers)
			plot = 'Artist:  '+artist+'[CR]Fans:  [COLOR FFFFA500]'+numbers+'[/COLOR]'
		elif EXTRA == 'album':
			name = translation(30778).format(special, version, numbers)
			plot = 'Artist:  '+artist+'[CR]Album:  '+album+'[CR]Version:  [COLOR deepskyblue]'+version+'[/COLOR][CR]Tracks:  [COLOR FFFFA500]'+numbers+'[/COLOR]'
		elif EXTRA == 'playlist':
			name = translation(30779).format(artist, user, numbers)
			plot = 'Artist:  '+artist+'[CR]User:  [COLOR deepskyblue]'+user+'[/COLOR][CR]Tracks:  [COLOR FFFFA500]'+numbers+'[/COLOR]'
		elif EXTRA == 'user':
			name = user
			plot = 'User:  [COLOR deepskyblue]'+user+'[/COLOR]'
		addAutoPlayDir(name, thumb, {'mode': 'listDeezerVideos', 'url': tracksUrl, 'extras': EXTRA, 'transmit': thumb}, plot)
	try:
		nextPage = content['next']
		if BASE_URL_DZ in nextPage:
			addDir(translation(30802), artpic+'nextpage.png', {'mode': 'listDeezerSelection', 'url': nextPage, 'extras': EXTRA})
	except: pass
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDPlaylists+')')

def listDeezerVideos(url, TYPE, LIMIT, EXTRA, PHOTO):
	musicVideos = []
	musicIsolated = set()
	counter = 0
	PLT = cleanPlaylist() if TYPE == 'play' else None
	if EXTRA == 'track' and not 'index=' in url:
		content = Transmission().makeREQUEST('{0}/{1}?q={2}&limit={3}&strict=on&output=json&index=0'.format(BASE_URL_DZ, EXTRA, url, deezerVideosDisplay))
	else:
		content = Transmission().makeREQUEST(url)
	for item in content['data']:
		artist = cleaning(item['artist']['name'])
		song = cleaning(item['title'])
		if song.isupper() or song.islower():
			song = TitleCase(song)
		plot = 'Artist:  '+artist+'[CR]'+'Song:  '+song
		firstTitle = artist+" - "+song
		if firstTitle in musicIsolated or artist == "":
			continue
		musicIsolated.add(firstTitle)
		album = cleaning(item['album']['title']) if EXTRA == 'track' else ""
		if album != "": plot += '[CR]'+'Album:  '+album
		if EXTRA == 'track':
			try: PHOTO = item['album']['cover_big']
			except: PHOTO = artpic+'noimage.png'
		for snippet in blackList:
			if snippet.strip().lower() and snippet.strip().lower() in firstTitle.lower():
				continue
		musicVideos.append([firstTitle, album, PHOTO, plot])
	if TYPE == 'browse':
		for firstTitle, album, PHOTO, plot in musicVideos:
			counter += 1
			name = translation(30780).format(firstTitle, album) if EXTRA == 'track' else translation(30801).format(str(counter), firstTitle)
			addLink(name, PHOTO, {'mode': 'playTITLE', 'url': fitme(firstTitle)}, plot)
		try:
			nextPage = content['next']
			if 'https://api.deezer.com/' in nextPage:
				addAutoPlayDir(translation(30802), artpic+'nextpage.png', {'mode': 'listDeezerVideos', 'url': nextPage, 'extras': EXTRA, 'transmit': PHOTO})
		except: pass
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if forceView:
			xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')
	else:
		if int(LIMIT) > 0:
			musicVideos = musicVideos[:int(LIMIT)]
		random.shuffle(musicVideos)
		for firstTitle, album, PHOTO, plot in musicVideos:
			endUrl = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playTITLE', 'url': fitme(firstTitle)}))
			listitem = xbmcgui.ListItem(firstTitle)
			listitem.setArt({'icon': icon, 'thumb': PHOTO, 'poster': PHOTO})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(endUrl, listitem)
		xbmc.Player().play(PLT)

def playTITLE(SUFFIX):
	query = 'official+'+quote_plus(SUFFIX.lower()).replace('%5B', '').replace('%5D', '').replace('%28', '').replace('%29', '').replace('%2F', '')
	FINAL_URL = False
	COMBI_VIDEO = []
	content = Transmission().retrieveContent('https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=5&order=relevance&q={}&key={}'.format(query, myTOKEN))
	for item in content.get('items', []):
		if item.get('id', {}).get('kind', '') == 'youtube#video':
			title = cleaning(item['snippet']['title'])
			IDD = item['id']['videoId']
			COMBI_VIDEO.append([title, IDD])
	if COMBI_VIDEO:
		parts = COMBI_VIDEO[:]
		matching = [s for s in parts if not 'audio' in s[0].lower() and not 'hörprobe' in s[0].lower()]
		youtubeID = matching[0][1] if matching else parts[0][1]
		FINAL_URL = '{0}?video_id={1}'.format('plugin://plugin.video.youtube/play/', str(youtubeID))
		log("(navigator.playTITLE) StreamURL : {0}".format(FINAL_URL))
		LSM = xbmcgui.ListItem(path=FINAL_URL)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		xbmc.sleep(1000)
		if enableINFOS: infoMessage()
	else:
		return dialog.notification(translation(30521).format('VIDEO'), translation(30526).format(SUFFIX), icon, 10000)

def infoMessage():
	counter = 0
	while not xbmc.Player().isPlaying():
		xbmc.sleep(200)
		if counter == 50:
			break
		counter += 1
	xbmc.sleep(infoDelay*1000)
	if xbmc.Player().isPlaying() and infoType == '0':
		xbmc.sleep(1500)
		xbmc.executebuiltin('ActivateWindow(12901)')
		xbmc.sleep(infoDuration*1000)
		xbmc.executebuiltin('ActivateWindow(12005)')
		xbmc.sleep(500)
		xbmc.executebuiltin('Action(Back)')
	elif xbmc.Player().isPlaying() and infoType == '1':
		xbmc.getInfoLabel('Player.Title')
		xbmc.getInfoLabel('Player.Duration')
		xbmc.getInfoLabel('Player.Art(thumb)')
		xbmc.sleep(500)
		TITLE = xbmc.getInfoLabel('Player.Title')
		if TITLE.isupper() or TITLE.islower():
			TITLE = TitleCase(TITLE)
		RUNTIME = xbmc.getInfoLabel('Player.Duration')
		PHOTO = xbmc.getInfoLabel('Player.Art(thumb)')
		xbmc.sleep(1000)
		dialog.notification(translation(30803), translation(30804).format(TITLE, RUNTIME), PHOTO, infoDuration*1000)
	else: pass

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot='...', folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	debug_MS("(navigator.{0}) ### NAME = {1} || PHOTO = {2} ###".format(params.get('mode', ''), name, image))
	debug_MS("(navigator.{0}) xxx PARAM = {1} xxx".format(params.get('mode', ''), u))
	liz = xbmcgui.ListItem(name)
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setPlot(plot)
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image})
	if useThumbAsFanart:
		liz.setArt({'fanart': defaultFanart})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addAutoPlayDir(name, image, params={}, plot='...'):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	debug_MS("(navigator.{0}) ### NAME = {1} || PHOTO = {2} ###".format(params.get('mode', ''), name, image))
	debug_MS("(navigator.{0}) xxx PARAM = {1} xxx".format(params.get('mode', ''), u))
	liz = xbmcgui.ListItem(name)
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setPlot(plot)
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image})
	if useThumbAsFanart:
		liz.setArt({'fanart': defaultFanart})
	entries = []
	entries.append([translation(30831), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': params.get('mode'), 'url': params.get('url'), 'target': 'play', 'extras': params.get('extras', ''), 'transmit': params.get('transmit', '')}))])
	entries.append([translation(30832), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': params.get('mode'), 'url': params.get('url'), 'target': 'play', 'limit': '10', 'extras': params.get('extras', ''), 'transmit': params.get('transmit', '')}))])
	entries.append([translation(30833), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': params.get('mode'), 'url': params.get('url'), 'target': 'play', 'limit': '20', 'extras': params.get('extras', ''), 'transmit': params.get('transmit', '')}))])
	entries.append([translation(30834), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': params.get('mode'), 'url': params.get('url'), 'target': 'play', 'limit': '30', 'extras': params.get('extras', ''), 'transmit': params.get('transmit', '')}))])
	entries.append([translation(30835), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': params.get('mode'), 'url': params.get('url'), 'target': 'play', 'limit': '40', 'extras': params.get('extras', ''), 'transmit': params.get('transmit', '')}))])
	entries.append([translation(30836), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': params.get('mode'), 'url': params.get('url'), 'target': 'play', 'limit': '50', 'extras': params.get('extras', ''), 'transmit': params.get('transmit', '')}))])
	liz.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)

def addLink(name, image, params={}, plot='...'):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	debug_MS("(navigator.{0}) ### NAME = {1} || PHOTO = {2} ###".format(params.get('mode', ''), name, image))
	debug_MS("(navigator.{0}) xxx PARAM = {1} xxx".format(params.get('mode', ''), u))
	liz = xbmcgui.ListItem(name)
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setPlot(plot), videoInfoTag.setMediaType('musicvideo')
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Mediatype': 'musicvideo'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image})
	if useThumbAsFanart:
		liz.setArt({'fanart': defaultFanart})
	liz.setProperty('IsPlayable', 'true')
	liz.addContextMenuItems([(translation(30805), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, 'mode=AddToQueue'))])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
