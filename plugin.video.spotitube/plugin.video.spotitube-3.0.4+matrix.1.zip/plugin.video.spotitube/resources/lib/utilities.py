﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import json
import xbmcvfs
import shutil
import time
import _strptime
from datetime import datetime, date, timedelta
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from .common import *


def _header(REFERRER=None, USERTOKEN=None):
	header = {}
	header['Pragma'] = 'no-cache'
	header['User-Agent'] = get_userAgent()
	header['DNT'] = '1'
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	header['Accept-Language'] = 'en-US,en;q=0.8,de;q=0.7'
	if REFERRER:
		header['Referer'] = REFERRER
	if USERTOKEN:
		header['Authorization'] = 'Bearer {}'.format(USERTOKEN)
	return header

class Transmission(object):

	def __init__(self):
		self.tempSESS_folder = tempSESS
		self.session_file = sessFile
		self.NOW_UTC = datetime.utcnow() # Actual UTC-Time
		self.verify_ssl = (True if addon.getSetting('verify_ssl') == 'true' else False)
		self.cache = cache
		self.session = requests.Session()

	def load_pagination(self, path, resource='albums'):
		first_page = self.makeREQUEST(path, forcing=True)
		DATA_ONE = first_page[resource] if resource == 'content' else first_page
		for item in DATA_ONE.get('items', []): yield item
		ALLPAGES = (int(DATA_ONE['total']) // int(DATA_ONE['limit']))+1 if DATA_ONE.get('total', '') and DATA_ONE.get('limit', '') else -1
		if 'users/' in path: ALLPAGES = 4
		debug_MS("(utilities.load_pagination) ### Total-Items : {0} || Result of PAGES : {1} ###".format(DATA_ONE.get('total', None), ALLPAGES))
		if ALLPAGES > 1 and DATA_ONE.get('next', ''):
			second_page =  self.makeREQUEST(DATA_ONE['next'], forcing=True)
			DATA_TWO = second_page[resource] if resource == 'content' else second_page
			for item in DATA_TWO.get('items', []): yield item
		if ALLPAGES > 2 and DATA_TWO.get('next', ''):
			third_page =  self.makeREQUEST(DATA_TWO['next'], forcing=True)
			DATA_THREE = third_page[resource] if resource == 'content' else third_page
			for item in DATA_THREE.get('items', []): yield item
		if ALLPAGES > 3 and DATA_THREE.get('next', ''):
			fourth_page =  self.makeREQUEST(DATA_THREE['next'], forcing=True)
			DATA_FOUR = fourth_page[resource] if resource == 'content' else fourth_page
			for item in DATA_FOUR.get('items', []): yield item

	def playlist_tracks(self, playlist_id, CYSO):
		endpoint = 'https://api.spotify.com/v1/playlists/{}/tracks?platform=web&country={}&offset=0&limit=100'.format(playlist_id, CYSO)
		return self.load_pagination(endpoint, resource='tracks')

	def user_playlists(self, endpoint, resource='content'):
		return self.load_pagination(endpoint, resource)

	def countries_alpha(self):
		COUNTRIES = [{'ne': 'Algeria','cd': 'DZ'},{'ne': 'Argentina','cd': 'AR'},{'ne': 'Australia','cd': 'AU'},{'ne': 'Austria','cd': 'AT'},{'ne': 'Azerbaijan','cd': 'AZ'},
			{'ne': 'Belarus','cd': 'BY'},{'ne': 'Belgium','cd': 'BE'},{'ne': 'Brazil','cd': 'BR'},{'ne': 'Bulgaria','cd': 'BG'},{'ne': 'Canada','cd': 'CA'},{'ne': 'Chile','cd': 'CL'},
			{'ne': 'China','cd': 'CN'},{'ne': 'Central Africa','cd': 'CF'},{'ne': 'Colombia','cd': 'CO'},{'ne': 'Costa Rica','cd': 'CR'},{'ne': 'Croatia','cd': 'HR'},{'ne': 'Cuba','cd': 'CU'},
			{'ne': 'Cyprus','cd': 'CY'},{'ne': 'Czech Republic','cd': 'CZ'},{'ne': 'Denmark','cd': 'DK'},{'ne': 'Dominican Republic','cd': 'DO'},{'ne': 'Ecuador','cd': 'EC'},{'ne': 'El Salvador','cd': 'SV'},
			{'ne': 'Estonia','cd': 'EE'},{'ne': 'Ethiopia','cd': 'ET'},{'ne': 'Finland','cd': 'FI'},{'ne': 'France','cd': 'FR'},{'ne': 'Gambia','cd': 'GM'},{'ne': 'Georgia','cd': 'GE'},
			{'ne': 'Germany','cd': 'DE'},{'ne': 'Ghana','cd': 'GH'},{'ne': 'Greece','cd': 'GR'},{'ne': 'Grenada','cd': 'GD'},{'ne': 'Haiti','cd': 'HT'},{'ne': 'Honduras','cd': 'HN'},
			{'ne': 'Hong Kong','cd': 'HK'},{'ne': 'Hungary','cd': 'HU'},{'ne': 'Iceland','cd': 'IS'},{'ne': 'India','cd': 'IN'},{'ne': 'Indonesia','cd': 'ID'},{'ne': 'Ireland','cd': 'IE'},
			{'ne': 'Israel','cd': 'IL'},{'ne': 'Italy','cd': 'IT'},{'ne': 'Jamaica','cd': 'JM'},{'ne': 'Japan','cd': 'JP'},{'ne': 'Jordan','cd': 'JO'},{'ne': 'Kenya','cd': 'KE'},
			{'ne': 'Korea','cd': 'KR'},{'ne': 'Kuwait','cd': 'KW'},{'ne': 'Latvia','cd': 'LV'},{'ne': 'Liberia','cd': 'LR'},{'ne': 'Libya','cd': 'LY'},{'ne': 'Liechtenstein','cd': 'LI'},
			{'ne': 'Luxembourg','cd': 'LU'},{'ne': 'Macedonia','cd': 'MK'},{'ne': 'Malta','cd': 'MT'},{'ne': 'Mexico','cd': 'MX'},{'ne': 'Monaco','cd': 'MC'},{'ne': 'Montenegro','cd': 'ME'},
			{'ne': 'Morocco','cd': 'MA'},{'ne': 'Netherlands','cd': 'NL'},{'ne': 'New Zealand','cd': 'NZ'},{'ne': 'Nicaragua','cd': 'NI'},{'ne': 'Nigeria','cd': 'NG'},{'ne': 'Norway','cd': 'NO'},
			{'ne': 'Pakistan','cd': 'PK'},{'ne': 'Panama','cd': 'PA'},{'ne': 'Paraguay','cd': 'PY'},{'ne': 'Peru','cd': 'PE'},{'ne': 'Philippines','cd': 'PH'},{'ne': 'Poland','cd': 'PL'},
			{'ne': 'Portugal','cd': 'PT'},{'ne': 'Puerto Rico','cd': 'PR'},{'ne': 'Romania','cd': 'RO'},{'ne': 'Russia','cd': 'RU'},{'ne': 'San Marino','cd': 'SM'},{'ne': 'Saudi Arabia','cd': 'SA'},
			{'ne': 'Senegal','cd': 'SN'},{'ne': 'Serbia','cd': 'RS'},{'ne': 'Singapore','cd': 'SG'},{'ne': 'Slovakia','cd': 'SK'},{'ne': 'Slovenia','cd': 'SI'},{'ne': 'Somalia','cd': 'SO'},
			{'ne': 'South Africa','cd': 'ZA'},{'ne': 'Spain','cd': 'ES'},{'ne': 'Sri Lanka','cd': 'LK'},{'ne': 'Sudan','cd': 'SD'},{'ne': 'Sweden','cd': 'SE'},{'ne': 'Switzerland','cd': 'CH'},
			{'ne': 'Taiwan','cd': 'TW'},{'ne': 'Tanzania','cd': 'TZ'},{'ne': 'Thailand','cd': 'TH'},{'ne': 'Tunisia','cd': 'TN'},{'ne': 'Turkey','cd': 'TR'},{'ne': 'Uganda','cd': 'UG'},
			{'ne': 'Ukraine','cd': 'UA'},{'ne': 'United Kingdom','cd': 'GB'},{'ne': 'United States','cd': 'US'},{'ne': 'Uruguay','cd': 'UY'},{'ne': 'Uzbekistan','cd': 'UZ'},{'ne': 'Venezuela','cd': 'VE'},
			{'ne': 'Viet Nam','cd': 'VN'},{'ne': 'Yemen','cd': 'YE'},{'ne': 'Zimbabwe','cd': 'ZW'}]
		return COUNTRIES

	def check_FreeToken(self):
		debug_MS("(utilities.check_FreeToken) -------------------------------------------------- START = check_FreeToken --------------------------------------------------")
		forceRenew, free_AUTH, expires = False, '0', 1658040792
		if self.session_file is not None and os.path.isfile(self.session_file):
			try:
				with open(self.session_file, 'r') as output:
					DATA = json.load(output)
				expires = DATA['accessTokenExpirationTimestampMs']
				EXPIRE_UTC = datetime(1970,1,1) + timedelta(milliseconds=expires - 120000) # 2 minutes minus for safety
				debug_MS("(utilities.check_FreeToken) ### SESSION-Time (utc NOW) = {} || VALID until (utc SESSION) = {} ###".format(str(self.NOW_UTC)[:19], str(EXPIRE_UTC)[:19]))
				if self.NOW_UTC < EXPIRE_UTC:
					debug_MS("(utilities.check_FreeToken) ##### NOTHING CHANGED - TOKENFILE OKAY #####")
					free_AUTH = DATA['accessToken']
				else:
					debug_MS("(utilities.check_FreeToken) ##### TIMEOUT FOR SESSION - DELETE TOKENFILE #####")
					forceRenew = True
			except:
				failing("(utilities.check_FreeToken) XXXXX !!! ERROR = TOKENFILE [TOKENFORMAT IS INVALID] = ERROR !!! XXXXX")
				forceRenew = True
		else:
			debug_MS("(utilities.check_FreeToken) ##### NOTHING FOUND - CREATE TOKENFILE #####")
			forceRenew = True
		if forceRenew:
			if self.session_file is not None and os.path.isfile(self.session_file):
				shutil.rmtree(self.tempSESS_folder, ignore_errors=True)
			CODING = self.retrieveContent('https://open.spotify.com/get_access_token?reason=transport&productType=web_player')
			if CODING:
				debug_MS("(utilities.check_FreeToken) ### NEW TOKENFILE CREATED : {0} ### ".format(CODING))
				if not xbmcvfs.exists(self.tempSESS_folder) and not os.path.isdir(self.tempSESS_folder):
					xbmcvfs.mkdirs(self.tempSESS_folder)
				with open(self.session_file, 'w') as input:
					json.dump(CODING, input, indent=4, sort_keys=True)
				free_AUTH = CODING['accessToken']
		return free_AUTH

	def makeREQUEST(self, url, method='GET', REF=None, forcing=False):
		content = self.cache.cacheFunction(self.retrieveContent, url, method, REF, forcing)
		return content

	def retrieveContent(self, url, method='GET', REF=None, forcing=False, headers=None, cookies=None, allow_redirects=True, stream=None, data=None, json=None):
		authtoken = self.check_FreeToken() if forcing is True else None
		ANSWER = None
		try:
			response = self.session.get(url, headers=_header(REF, authtoken), allow_redirects=allow_redirects, verify=self.verify_ssl, stream=stream, timeout=30)
			ANSWER = response.json() if method in ['GET', 'POST'] else response.text
			debug_MS("(common.getUrl) === CALLBACK === status : {} || url : {} || header : {} ===".format(response.status_code, response.url, _header(REF, authtoken)))
		except requests.exceptions.RequestException as e:
			failing("(common.getUrl) ERROR - ERROR - ERROR ##### url: {} === error: {} #####".format(url, str(e)))
			dialog.notification(translation(30521).format('URL'), translation(30523).format(str(e)), icon, 12000)
			return sys.exit(0)
		return ANSWER
