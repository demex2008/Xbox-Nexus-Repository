# -*- coding=utf8 -*-
#******************************************************************************
# Config.py
#------------------------------------------------------------------------------
#
# Copyright (c) 2014-2015 LivingOn <LivingOn@xmail.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#******************************************************************************
import xbmc,xbmcvfs

class Config(object):
    "Die wichtigsten Konfigurationsparameter zusammengefasst."
    
    PLUGIN_NAME    = "plugin.video.chaturbate"
    CHATURBATE_URL = "https://de.chaturbate.com/"

    CHATURBATE_URL_FEATURED    = CHATURBATE_URL 
    CHATURBATE_URL_WEIBLICH    = CHATURBATE_URL + "female-cams/"
    CHATURBATE_URL_MAENNLICH   = CHATURBATE_URL + "male-cams/"
    CHATURBATE_URL_PAAR        = CHATURBATE_URL + "couple-cams/"
    CHATURBATE_URL_TRANSSEXUAL = CHATURBATE_URL + "trans-cams/"

    CHATURBATE_URL_TEEN18      = CHATURBATE_URL + "teen-cams/"
    CHATURBATE_URL_18to21      = CHATURBATE_URL + "18to21-cams/"
    CHATURBATE_URL_20to30      = CHATURBATE_URL + "20to30-cams/"
    CHATURBATE_URL_30to50      = CHATURBATE_URL + "30to50-cams/"
    CHATURBATE_URL_50plus      = CHATURBATE_URL + "mature-cams/"

    CHATURBATE_URL_EURO        = CHATURBATE_URL + "euro-russian-cams/"
    CHATURBATE_URL_NAMERICA    = CHATURBATE_URL + "north-american-cams/"
    CHATURBATE_URL_SAMERICA    = CHATURBATE_URL + "south-american-cams/"
    CHATURBATE_URL_ASIA        = CHATURBATE_URL + "asian-cams/"
    CHATURBATE_URL_OREGION     = CHATURBATE_URL + "other-region-cams/"

    CHATURBATE_URL_NEWCAMS     = CHATURBATE_URL + "new-cams/"
    CHATURBATE_URL_EXICAMS     = CHATURBATE_URL + "exhibitionist-cams/"

    CHATURBATE_URL_FEATURED_TAGS    = CHATURBATE_URL + "tags/"
    CHATURBATE_URL_WEIBLICH_TAGS    = CHATURBATE_URL + "tags/female/"
    CHATURBATE_URL_MAENNLICH_TAGS   = CHATURBATE_URL + "tags/male/"
    CHATURBATE_URL_PAAR_TAGS        = CHATURBATE_URL + "tags/couple/"
    CHATURBATE_URL_TRANSSEXUAL_TAGS = CHATURBATE_URL + "tags/trans/"

    SCRIPT_SETTINGS = "settings.py"
    SCRIPT_INSERT_FAVORITE = "insert_actor.py"
    SCRIPT_REMOVE_FAVORITE = "remove_actor.py"

    FAVORITS_DB = xbmcvfs.translatePath(
        "special://profile/addon_data/%s/Favorits.db" % PLUGIN_NAME
    )

    M3U8_PATTERN = "(https:[^>\s]+?.m3u8)"

    CHUNK_PLAYER_PORT = 18517